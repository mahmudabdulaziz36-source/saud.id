// routes/messages.js — direct message ASLI, tersimpan di database, diambil lewat polling

const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth);

// ---------- DAFTAR PERCAKAPAN (kontak unik + pesan terakhir) ----------
router.get('/conversations', (req, res) => {
  const me = req.session.userId;
  const rows = db.prepare(`
    SELECT u.id, u.username, u.fullname, u.avatar_path,
      (SELECT text FROM messages m2
        WHERE (m2.sender_id = u.id AND m2.receiver_id = ?) OR (m2.sender_id = ? AND m2.receiver_id = u.id)
        ORDER BY m2.id DESC LIMIT 1) AS last_message,
      (SELECT created_at FROM messages m3
        WHERE (m3.sender_id = u.id AND m3.receiver_id = ?) OR (m3.sender_id = ? AND m3.receiver_id = u.id)
        ORDER BY m3.id DESC LIMIT 1) AS last_time,
      (SELECT COUNT(*) FROM messages m4 WHERE m4.sender_id = u.id AND m4.receiver_id = ? AND m4.is_read = 0) AS unread_count
    FROM users u
    WHERE u.id IN (
      SELECT sender_id FROM messages WHERE receiver_id = ?
      UNION
      SELECT receiver_id FROM messages WHERE sender_id = ?
    )
    ORDER BY last_time DESC
  `).all(me, me, me, me, me, me, me);

  res.json({ conversations: rows });
});

// ---------- RIWAYAT PESAN DENGAN SATU USER ----------
router.get('/with/:username', (req, res) => {
  const me = req.session.userId;
  const other = db.prepare('SELECT id, username, fullname, avatar_path FROM users WHERE username = ?')
    .get(req.params.username.toLowerCase());
  if (!other) return res.status(404).json({ error: 'User tidak ditemukan.' });

  const rows = db.prepare(`
    SELECT id, sender_id, receiver_id, text, created_at
    FROM messages
    WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
    ORDER BY id ASC
    LIMIT 200
  `).all(me, other.id, other.id, me);

  db.prepare('UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?').run(other.id, me);

  res.json({ other, messages: rows });
});

// ---------- KIRIM PESAN (real, persisten) ----------
router.post('/with/:username', (req, res) => {
  const me = req.session.userId;
  const { text } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'Pesan tidak boleh kosong.' });

  const other = db.prepare('SELECT id FROM users WHERE username = ?').get(req.params.username.toLowerCase());
  if (!other) return res.status(404).json({ error: 'User tidak ditemukan.' });
  if (other.id === me) return res.status(400).json({ error: 'Tidak bisa mengirim pesan ke diri sendiri.' });

  const result = db.prepare(`
    INSERT INTO messages (sender_id, receiver_id, text) VALUES (?, ?, ?)
  `).run(me, other.id, text.trim());

  const message = db.prepare('SELECT * FROM messages WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({ message });
});

// ---------- JUMLAH PESAN BELUM DIBACA (untuk badge) ----------
router.get('/unread-count', (req, res) => {
  const count = db.prepare(
    'SELECT COUNT(*) AS c FROM messages WHERE receiver_id = ? AND is_read = 0'
  ).get(req.session.userId).c;
  res.json({ count });
});

module.exports = router;
