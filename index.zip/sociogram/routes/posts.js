// routes/posts.js — semua data di sini ASLI dari database. Tidak ada post/komentar/like contoh.

const express = require('express');
const db = require('../db');
const upload = require('../middleware/upload');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// ---------- BUAT POST (wajib login, wajib upload gambar asli) ----------
router.post('/', requireAuth, upload.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'Gambar wajib diunggah untuk membuat post.' });
  }
  const { caption = '', location = '' } = req.body;
  const imagePath = `/uploads/${req.file.filename}`;

  const result = db.prepare(`
    INSERT INTO posts (user_id, image_path, caption, location)
    VALUES (?, ?, ?, ?)
  `).run(req.session.userId, imagePath, caption.trim(), location.trim());

  const post = getPostById(result.lastInsertRowid, req.session.userId);
  res.status(201).json({ message: 'Post berhasil diunggah.', post });
});

// ---------- FEED (real, diurutkan dari post terbaru) ----------
router.get('/feed', (req, res) => {
  const viewerId = req.session.userId || 0;
  const limit = Math.min(parseInt(req.query.limit) || 10, 50);
  const before = req.query.before ? parseInt(req.query.before) : null;

  let rows;
  if (before) {
    rows = db.prepare(`
      SELECT p.*, u.username, u.fullname, u.avatar_path,
        (SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id) AS like_count,
        (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) AS comment_count,
        EXISTS(SELECT 1 FROM likes l2 WHERE l2.post_id = p.id AND l2.user_id = ?) AS liked_by_me
      FROM posts p JOIN users u ON u.id = p.user_id
      WHERE p.id < ?
      ORDER BY p.id DESC LIMIT ?
    `).all(viewerId, before, limit);
  } else {
    rows = db.prepare(`
      SELECT p.*, u.username, u.fullname, u.avatar_path,
        (SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id) AS like_count,
        (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) AS comment_count,
        EXISTS(SELECT 1 FROM likes l2 WHERE l2.post_id = p.id AND l2.user_id = ?) AS liked_by_me
      FROM posts p JOIN users u ON u.id = p.user_id
      ORDER BY p.id DESC LIMIT ?
    `).all(viewerId, limit);
  }

  const posts = rows.map(r => ({
    id: r.id,
    caption: r.caption,
    location: r.location,
    image_path: r.image_path,
    created_at: r.created_at,
    like_count: r.like_count,
    comment_count: r.comment_count,
    liked_by_me: !!r.liked_by_me,
    user: { id: r.user_id, username: r.username, fullname: r.fullname, avatar_path: r.avatar_path }
  }));

  res.json({ posts, next_before: posts.length ? posts[posts.length - 1].id : null });
});

// ---------- EXPLORE (grid post, urut populer, real data) ----------
router.get('/explore/grid', (req, res) => {
  const rows = db.prepare(`
    SELECT p.id, p.image_path,
      (SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id) AS like_count,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) AS comment_count
    FROM posts p
    ORDER BY like_count DESC, p.id DESC
    LIMIT 60
  `).all();
  res.json({ posts: rows });
});

// ---------- DETAIL SATU POST + KOMENTAR ASLI ----------
router.get('/:id', (req, res) => {
  const post = getPostById(req.params.id, req.session.userId || 0);
  if (!post) return res.status(404).json({ error: 'Post tidak ditemukan.' });

  const comments = db.prepare(`
    SELECT c.id, c.text, c.created_at, u.username, u.avatar_path
    FROM comments c JOIN users u ON u.id = c.user_id
    WHERE c.post_id = ? ORDER BY c.id ASC
  `).all(req.params.id);

  res.json({ post, comments });
});

// ---------- LIKE / UNLIKE (toggle nyata, tersimpan di DB) ----------
router.post('/:id/like', requireAuth, (req, res) => {
  const postId = req.params.id;
  const exists = db.prepare('SELECT 1 FROM posts WHERE id = ?').get(postId);
  if (!exists) return res.status(404).json({ error: 'Post tidak ditemukan.' });

  const already = db.prepare('SELECT 1 FROM likes WHERE post_id = ? AND user_id = ?')
    .get(postId, req.session.userId);

  if (already) {
    db.prepare('DELETE FROM likes WHERE post_id = ? AND user_id = ?').run(postId, req.session.userId);
  } else {
    db.prepare('INSERT INTO likes (post_id, user_id) VALUES (?, ?)').run(postId, req.session.userId);
    const post = db.prepare('SELECT user_id FROM posts WHERE id = ?').get(postId);
    if (post.user_id !== req.session.userId) {
      db.prepare(`
        INSERT INTO notifications (user_id, actor_id, type, post_id) VALUES (?, ?, 'like', ?)
      `).run(post.user_id, req.session.userId, postId);
    }
  }

  const count = db.prepare('SELECT COUNT(*) AS c FROM likes WHERE post_id = ?').get(postId).c;
  res.json({ liked: !already, like_count: count });
});

// ---------- TAMBAH KOMENTAR (real, persisten) ----------
router.post('/:id/comments', requireAuth, (req, res) => {
  const postId = req.params.id;
  const { text } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Komentar tidak boleh kosong.' });
  }
  const exists = db.prepare('SELECT 1 FROM posts WHERE id = ?').get(postId);
  if (!exists) return res.status(404).json({ error: 'Post tidak ditemukan.' });

  const result = db.prepare(`
    INSERT INTO comments (post_id, user_id, text) VALUES (?, ?, ?)
  `).run(postId, req.session.userId, text.trim());

  const postOwner = db.prepare('SELECT user_id FROM posts WHERE id = ?').get(postId);
  if (postOwner.user_id !== req.session.userId) {
    db.prepare(`
      INSERT INTO notifications (user_id, actor_id, type, post_id) VALUES (?, ?, 'comment', ?)
    `).run(postOwner.user_id, req.session.userId, postId);
  }

  const comment = db.prepare(`
    SELECT c.id, c.text, c.created_at, u.username, u.avatar_path
    FROM comments c JOIN users u ON u.id = c.user_id WHERE c.id = ?
  `).get(result.lastInsertRowid);

  res.status(201).json({ comment });
});

// ---------- HAPUS POST (hanya pemilik) ----------
router.delete('/:id', requireAuth, (req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: 'Post tidak ditemukan.' });
  if (post.user_id !== req.session.userId) {
    return res.status(403).json({ error: 'Kamu tidak berhak menghapus post ini.' });
  }
  db.prepare('DELETE FROM posts WHERE id = ?').run(req.params.id);
  res.json({ message: 'Post dihapus.' });
});

function getPostById(id, viewerId) {
  const r = db.prepare(`
    SELECT p.*, u.username, u.fullname, u.avatar_path,
      (SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id) AS like_count,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) AS comment_count,
      EXISTS(SELECT 1 FROM likes l2 WHERE l2.post_id = p.id AND l2.user_id = ?) AS liked_by_me
    FROM posts p JOIN users u ON u.id = p.user_id WHERE p.id = ?
  `).get(viewerId, id);
  if (!r) return null;
  return {
    id: r.id, caption: r.caption, location: r.location, image_path: r.image_path,
    created_at: r.created_at, like_count: r.like_count, comment_count: r.comment_count,
    liked_by_me: !!r.liked_by_me,
    user: { id: r.user_id, username: r.username, fullname: r.fullname, avatar_path: r.avatar_path }
  };
}

module.exports = router;
