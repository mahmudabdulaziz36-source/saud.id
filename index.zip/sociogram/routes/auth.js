// routes/auth.js — autentikasi ASLI: password di-hash dengan bcrypt, validasi nyata, sesi sungguhan

const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../db');
const upload = require('../middleware/upload');

const router = express.Router();
const SALT_ROUNDS = 12;

const USERNAME_RE = /^[a-z0-9_.]{3,20}$/;

function validateRegisterInput({ username, password, fullname }) {
  const errors = [];
  if (!username || !USERNAME_RE.test(username)) {
    errors.push('Username harus 3-20 karakter: huruf kecil, angka, titik, atau garis bawah saja.');
  }
  if (!password || password.length < 8) {
    errors.push('Password minimal 8 karakter.');
  }
  if (!fullname || fullname.trim().length < 2) {
    errors.push('Nama lengkap minimal 2 karakter.');
  }
  return errors;
}

// ---------- REGISTER ----------
router.post('/register', upload.single('avatar'), (req, res) => {
  const { username, password, fullname } = req.body;
  const errors = validateRegisterInput({ username, password, fullname });

  if (errors.length) {
    return res.status(400).json({ error: errors.join(' ') });
  }

  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username.toLowerCase());
  if (existing) {
    return res.status(409).json({ error: 'Username sudah digunakan, coba yang lain.' });
  }

  const password_hash = bcrypt.hashSync(password, SALT_ROUNDS);
  const avatarPath = req.file ? `/uploads/${req.file.filename}` : null;

  const result = db.prepare(`
    INSERT INTO users (username, password_hash, fullname, avatar_path)
    VALUES (?, ?, ?, ?)
  `).run(username.toLowerCase(), password_hash, fullname.trim(), avatarPath);

  req.session.userId = result.lastInsertRowid;
  res.status(201).json({
    message: 'Akun berhasil dibuat.',
    user: { id: result.lastInsertRowid, username: username.toLowerCase(), fullname, avatar_path: avatarPath }
  });
});

// ---------- LOGIN ----------
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username dan password wajib diisi.' });
  }

  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username.toLowerCase());
  if (!user) {
    return res.status(401).json({ error: 'Username atau password salah.' });
  }

  const valid = bcrypt.compareSync(password, user.password_hash);
  if (!valid) {
    return res.status(401).json({ error: 'Username atau password salah.' });
  }

  req.session.userId = user.id;
  res.json({
    message: 'Login berhasil.',
    user: { id: user.id, username: user.username, fullname: user.fullname, avatar_path: user.avatar_path }
  });
});

// ---------- LOGOUT ----------
router.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: 'Gagal logout.' });
    res.clearCookie('connect.sid');
    res.json({ message: 'Logout berhasil.' });
  });
});

// ---------- CEK SESI SAAT INI ----------
router.get('/me', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Belum login.' });
  }
  const user = db.prepare(
    'SELECT id, username, fullname, bio, avatar_path, created_at FROM users WHERE id = ?'
  ).get(req.session.userId);
  if (!user) return res.status(401).json({ error: 'Belum login.' });
  res.json({ user });
});

module.exports = router;
