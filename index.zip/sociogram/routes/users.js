// routes/users.js — profil, follow/unfollow, dan pencarian user ASLI dari database

const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../db');
const upload = require('../middleware/upload');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// ---------- PENCARIAN USER (untuk explore / search bar) ----------
router.get('/search', (req, res) => {
  const q = (req.query.q || '').trim().toLowerCase();
  if (!q) return res.json({ users: [] });

  const rows = db.prepare(`
    SELECT id, username, fullname, avatar_path
    FROM users
    WHERE username LIKE ? OR fullname LIKE ?
    ORDER BY username ASC LIMIT 20
  `).all(`%${q}%`, `%${q}%`);

  res.json({ users: rows });
});

// ---------- PROFIL PUBLIK BERDASARKAN USERNAME ----------
router.get('/:username', (req, res) => {
  const viewerId = req.session.userId || 0;
  const username = req.params.username.toLowerCase();

  const user = db.prepare(
    'SELECT id, username, fullname, bio, avatar_path, created_at FROM users WHERE username = ?'
  ).get(username);
  if (!user) return res.status(404).json({ error: 'User tidak ditemukan.' });

  const postCount = db.prepare('SELECT COUNT(*) AS c FROM posts WHERE user_id = ?').get(user.id).c;
  const followerCount = db.prepare('SELECT COUNT(*) AS c FROM follows WHERE following_id = ?').get(user.id).c;
  const followingCount = db.prepare('SELECT COUNT(*) AS c FROM follows WHERE follower_id = ?').get(user.id).c;
  const isFollowing = viewerId
    ? !!db.prepare('SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?').get(viewerId, user.id)
    : false;

  const posts = db.prepare(`
    SELECT id, image_path,
      (SELECT COUNT(*) FROM likes l WHERE l.post_id = posts.id) AS like_count,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id = posts.id) AS comment_count
    FROM posts WHERE user_id = ? ORDER BY id DESC
  `).all(user.id);

  res.json({
    user: { ...user, is_me: viewerId === user.id },
    stats: { posts: postCount, followers: followerCount, following: followingCount },
    is_following: isFollowing,
    posts
  });
});

// ---------- EDIT PROFIL (hanya diri sendiri) ----------
router.put('/me', requireAuth, upload.single('avatar'), (req, res) => {
  const { fullname, bio } = req.body;
  const fields = [];
  const values = [];

  if (fullname !== undefined) {
    if (!fullname.trim() || fullname.trim().length < 2) {
      return res.status(400).json({ error: 'Nama lengkap minimal 2 karakter.' });
    }
    fields.push('fullname = ?');
    values.push(fullname.trim());
  }
  if (bio !== undefined) {
    if (bio.length > 150) {
      return res.status(400).json({ error: 'Bio maksimal 150 karakter.' });
    }
    fields.push('bio = ?');
    values.push(bio);
  }
  if (req.file) {
    fields.push('avatar_path = ?');
    values.push(`/uploads/${req.file.filename}`);
  }

  if (fields.length === 0) {
    return res.status(400).json({ error: 'Tidak ada perubahan yang dikirim.' });
  }

  values.push(req.session.userId);
  db.prepare(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`).run(...values);

  const updated = db.prepare(
    'SELECT id, username, fullname, bio, avatar_path FROM users WHERE id = ?'
  ).get(req.session.userId);

  res.json({ message: 'Profil berhasil diperbarui.', user: updated });
});

// ---------- GANTI PASSWORD ----------
router.put('/me/password', requireAuth, (req, res) => {
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password || new_password.length < 8) {
    return res.status(400).json({ error: 'Password baru minimal 8 karakter.' });
  }
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);
  if (!bcrypt.compareSync(current_password, user.password_hash)) {
    return res.status(401).json({ error: 'Password saat ini salah.' });
  }
  const newHash = bcrypt.hashSync(new_password, 12);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newHash, req.session.userId);
  res.json({ message: 'Password berhasil diganti.' });
});

// ---------- FOLLOW / UNFOLLOW (toggle nyata) ----------
router.post('/:username/follow', requireAuth, (req, res) => {
  const target = db.prepare('SELECT id FROM users WHERE username = ?').get(req.params.username.toLowerCase());
  if (!target) return res.status(404).json({ error: 'User tidak ditemukan.' });
  if (target.id === req.session.userId) {
    return res.status(400).json({ error: 'Tidak bisa mengikuti diri sendiri.' });
  }

  const already = db.prepare('SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?')
    .get(req.session.userId, target.id);

  if (already) {
    db.prepare('DELETE FROM follows WHERE follower_id = ? AND following_id = ?').run(req.session.userId, target.id);
  } else {
    db.prepare('INSERT INTO follows (follower_id, following_id) VALUES (?, ?)').run(req.session.userId, target.id);
    db.prepare(`
      INSERT INTO notifications (user_id, actor_id, type) VALUES (?, ?, 'follow')
    `).run(target.id, req.session.userId);
  }

  const followerCount = db.prepare('SELECT COUNT(*) AS c FROM follows WHERE following_id = ?').get(target.id).c;
  res.json({ following: !already, follower_count: followerCount });
});

// ---------- DAFTAR FOLLOWER / FOLLOWING ----------
router.get('/:username/followers', (req, res) => {
  const user = db.prepare('SELECT id FROM users WHERE username = ?').get(req.params.username.toLowerCase());
  if (!user) return res.status(404).json({ error: 'User tidak ditemukan.' });
  const rows = db.prepare(`
    SELECT u.id, u.username, u.fullname, u.avatar_path
    FROM follows f JOIN users u ON u.id = f.follower_id
    WHERE f.following_id = ? ORDER BY f.created_at DESC
  `).all(user.id);
  res.json({ users: rows });
});

router.get('/:username/following', (req, res) => {
  const user = db.prepare('SELECT id FROM users WHERE username = ?').get(req.params.username.toLowerCase());
  if (!user) return res.status(404).json({ error: 'User tidak ditemukan.' });
  const rows = db.prepare(`
    SELECT u.id, u.username, u.fullname, u.avatar_path
    FROM follows f JOIN users u ON u.id = f.following_id
    WHERE f.follower_id = ? ORDER BY f.created_at DESC
  `).all(user.id);
  res.json({ users: rows });
});

module.exports = router;
