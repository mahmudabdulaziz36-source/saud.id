// routes/notifications.js — notifikasi ASLI, dipicu oleh like/comment/follow sungguhan

const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth);

// ---------- DAFTAR NOTIFIKASI ----------
router.get('/', (req, res) => {
  const rows = db.prepare(`
    SELECT n.id, n.type, n.is_read, n.created_at, n.post_id,
           u.username AS actor_username, u.avatar_path AS actor_avatar,
           p.image_path AS post_image
    FROM notifications n
    JOIN users u ON u.id = n.actor_id
    LEFT JOIN posts p ON p.id = n.post_id
    WHERE n.user_id = ?
    ORDER BY n.id DESC
    LIMIT 50
  `).all(req.session.userId);

  res.json({ notifications: rows });
});

// ---------- JUMLAH BELUM DIBACA (untuk badge di topbar) ----------
router.get('/unread-count', (req, res) => {
  const count = db.prepare(
    'SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0'
  ).get(req.session.userId).c;
  res.json({ count });
});

// ---------- TANDAI SEMUA SUDAH DIBACA ----------
router.post('/mark-read', (req, res) => {
  db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.session.userId);
  res.json({ message: 'Semua notifikasi ditandai sudah dibaca.' });
});

module.exports = router;
