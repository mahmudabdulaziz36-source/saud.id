# Sociogram — Tahap 1+2+3: Backend Sungguhan Lengkap

Ini bukan demo dengan data palsu. Semua user, post, gambar, like, komentar, follow,
notifikasi, dan pesan tersimpan permanen di server kamu (SQLite + folder `uploads/`).

## Yang sudah jalan (Tahap 1-3)
- Registrasi & login sungguhan (bcrypt + sesi tersimpan di file)
- Upload foto post ASLI, feed nyata dengan pagination
- Like/unlike & komentar persisten, halaman detail post, hapus post
- Profil publik, edit profil, ganti password
- Follow/unfollow sungguhan, daftar pengikut & yang diikuti
- Pencarian pengguna real-time, explore grid post populer
- **Notifikasi** sungguhan (dipicu otomatis saat ada yang like/komentar/follow kamu),
  dengan badge jumlah belum dibaca di topbar
- **Pesan langsung (DM)** sungguhan, tersimpan permanen, update otomatis tiap 3 detik
  (polling) selama jendela chat terbuka — tidak perlu refresh manual

## Yang BELUM ada (menyusul di tahap berikutnya)
- Stories (foto/video yang hilang setelah 24 jam)
- WebSocket untuk chat benar-benar real-time (saat ini pakai polling 3 detik, sudah
  cukup responsif untuk skala kecil-menengah)
- HTTPS otomatis (wajib kamu pasang sebelum live ke publik — lihat di bawah)

## Cara menjalankan di VPS kamu

1. Pastikan Node.js versi 18+ terpasang:
   ```
   node -v
   ```
   Kalau belum ada, instal lewat NodeSource atau nvm.

2. Upload folder project ini ke VPS (lewat `git clone`, `scp`, atau `rsync`).

3. Masuk ke folder project, install dependency:
   ```
   cd sociogram
   npm install
   ```

4. Salin file environment dan isi nilai rahasianya:
   ```
   cp .env.example .env
   nano .env
   ```
   Ganti `SESSION_SECRET` dengan string acak panjang (jangan dibiarkan default).

5. Jalankan server:
   ```
   npm start
   ```
   Server berjalan di `http://localhost:3000` (atau `PORT` yang kamu atur).

6. **Supaya bisa diakses publik dari internet**, kamu butuh:
   - **Domain** yang diarahkan (DNS A record) ke IP VPS kamu.
   - **Reverse proxy** seperti Nginx untuk meneruskan port 80/443 ke port 3000 Node.
   - **HTTPS** lewat Certbot/Let's Encrypt (wajib — browser modern memblokir banyak
     fitur di situs HTTP biasa, dan login tanpa HTTPS tidak aman).
   - **Process manager** seperti PM2 supaya server otomatis restart kalau crash atau VPS reboot:
     ```
     npm install -g pm2
     pm2 start server.js --name sociogram
     pm2 save
     pm2 startup
     ```

   Contoh konfigurasi Nginx dasar (sesuaikan domain):
   ```nginx
   server {
       listen 80;
       server_name domainkamu.com;
       location / {
           proxy_pass http://localhost:3000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
   }
   ```
   Lalu jalankan: `sudo certbot --nginx -d domainkamu.com`

7. Setelah HTTPS aktif, buka `.env` dan set `FORCE_HTTPS=true` supaya cookie sesi
   dikirim hanya lewat koneksi aman.

## Struktur folder
```
sociogram/
├── server.js          # entry point
├── db.js              # skema & koneksi SQLite
├── middleware/
│   ├── auth.js         # proteksi route + ambil user dari sesi
│   └── upload.js        # konfigurasi multer (upload gambar asli)
├── routes/
│   ├── auth.js          # register/login/logout/me
│   └── posts.js         # CRUD post, like, comment
├── public/             # frontend (HTML/CSS/JS statis)
│   ├── login.html
│   ├── register.html
│   ├── index.html       # feed utama
│   ├── post.html         # detail post + komentar
│   └── uploads/          # foto asli tersimpan di sini
└── data/sociogram.db   # database SQLite (dibuat otomatis saat pertama jalan)
```

## Lanjut ke tahap berikutnya?
Beri tahu saya kalau Tahap 1 sudah berhasil kamu jalankan di VPS, lalu kita lanjut
membangun: profil, follow system, explore, DM, notifikasi, dan stories — dengan
cara yang sama (backend + database asli, tanpa data dummy).
