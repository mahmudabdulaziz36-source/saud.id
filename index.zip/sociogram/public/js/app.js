// public/js/app.js — semua data berasal dari API server. Tidak ada array dummy di sini.

const DEFAULT_AVATAR = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Ccircle cx='12' cy='12' r='12' fill='%23262c33'/%3E%3C/svg%3E";

let currentUser = null;
let nextBefore = null;

/* ======================================================
   AUTH GUARD — pastikan user benar-benar login lewat API
   ====================================================== */
async function checkAuth() {
  const res = await fetch('/api/auth/me', { headers: { Accept: 'application/json' } });
  if (!res.ok) {
    window.location.href = '/login.html';
    return null;
  }
  const data = await res.json();
  return data.user;
}

function fmtAvatar(path) {
  return path || DEFAULT_AVATAR;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function formatCaption(text) {
  return escapeHtml(text).replace(/#(\w+)/g, '<span style="color:#8ab4ff">#$1</span>');
}

function timeAgo(isoString) {
  const diffMs = Date.now() - new Date(isoString + 'Z').getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'BARU SAJA';
  if (mins < 60) return `${mins} MENIT LALU`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} JAM LALU`;
  const days = Math.floor(hours / 24);
  return `${days} HARI LALU`;
}

/* ======================================================
   FEED — diambil murni dari /api/posts/feed
   ====================================================== */
async function loadFeed(reset = true) {
  const url = new URL('/api/posts/feed', window.location.origin);
  url.searchParams.set('limit', 10);
  if (!reset && nextBefore) url.searchParams.set('before', nextBefore);

  const res = await fetch(url, { headers: { Accept: 'application/json' } });
  const data = await res.json();

  const feedEl = document.getElementById('feed');
  if (reset) feedEl.innerHTML = '';

  if (data.posts.length === 0 && reset) {
    feedEl.innerHTML = `
      <div class="empty-state">
        <div class="big">📷</div>
        <p>Belum ada postingan. Jadilah yang pertama membagikan momenmu.</p>
      </div>`;
    document.getElementById('loadMoreWrap').style.display = 'none';
    return;
  }

  data.posts.forEach(p => feedEl.insertAdjacentHTML('beforeend', postTemplate(p)));
  nextBefore = data.next_before;
  document.getElementById('loadMoreWrap').style.display = data.posts.length === 10 ? 'block' : 'none';
}

function postTemplate(p) {
  return `
  <article class="post" data-id="${p.id}">
    <div class="post-head">
      <div class="post-user">
        <img class="avatar" src="${fmtAvatar(p.user.avatar_path)}">
        <div class="post-user-meta">
          <span class="post-username">${escapeHtml(p.user.username)}</span>
          ${p.location ? `<span class="post-location">${escapeHtml(p.location)}</span>` : ''}
        </div>
      </div>
      ${p.user.id === currentUser.id ? `<button class="more-btn" onclick="deletePost(${p.id})">🗑</button>` : `<button class="more-btn">⋯</button>`}
    </div>

    <div class="post-media" ondblclick="likePost(${p.id}, true)">
      <img src="${p.image_path}" alt="post" loading="lazy">
      <span class="heart-pop" id="heart-${p.id}">❤️</span>
    </div>

    <div class="post-actions">
      <div class="action-left">
        <button class="action-btn ${p.liked_by_me ? 'liked' : ''}" id="like-btn-${p.id}" onclick="likePost(${p.id})">${p.liked_by_me ? '❤️' : '🤍'}</button>
        <button class="action-btn" onclick="focusComment(${p.id})">💬</button>
      </div>
    </div>

    <div class="post-likes" id="likes-${p.id}">${p.like_count.toLocaleString('id-ID')} suka</div>

    ${p.caption ? `<div class="post-caption"><span class="cap-username">${escapeHtml(p.user.username)}</span>${formatCaption(p.caption)}</div>` : ''}

    ${p.comment_count > 0 ? `<div class="comments-link" style="cursor:pointer" onclick="openComments(${p.id})">Lihat semua ${p.comment_count} komentar</div>` : ''}

    <div class="comment-time">${timeAgo(p.created_at)}</div>

    <div class="add-comment">
      <input type="text" placeholder="Tambahkan komentar..." id="input-${p.id}" onkeyup="onCommentInput(${p.id}, event)">
      <button class="post-btn" id="post-btn-${p.id}" onclick="addComment(${p.id})">Kirim</button>
    </div>
  </article>`;
}

/* ---------- LIKE (real toggle via API) ---------- */
async function likePost(id, fromDoubleClick) {
  const btn = document.getElementById(`like-btn-${id}`);
  const alreadyLiked = btn.classList.contains('liked');
  if (fromDoubleClick && alreadyLiked) {
    popHeart(id);
    return;
  }
  const res = await fetch(`/api/posts/${id}/like`, { method: 'POST' });
  if (!res.ok) { toast('Gagal menyukai post.'); return; }
  const data = await res.json();
  document.getElementById(`likes-${id}`).textContent = `${data.like_count.toLocaleString('id-ID')} suka`;
  btn.textContent = data.liked ? '❤️' : '🤍';
  btn.classList.toggle('liked', data.liked);
  if (data.liked) popHeart(id);
}

function popHeart(id) {
  const heart = document.getElementById(`heart-${id}`);
  heart.classList.remove('animate');
  void heart.offsetWidth;
  heart.classList.add('animate');
}

/* ---------- KOMENTAR (real, tersimpan di DB) ---------- */
function onCommentInput(id, e) {
  const val = document.getElementById(`input-${id}`).value.trim();
  document.getElementById(`post-btn-${id}`).classList.toggle('active', val.length > 0);
  if (e.key === 'Enter' && val.length > 0) addComment(id);
}

async function addComment(id) {
  const input = document.getElementById(`input-${id}`);
  const text = input.value.trim();
  if (!text) return;
  const res = await fetch(`/api/posts/${id}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text })
  });
  if (!res.ok) { toast('Gagal mengirim komentar.'); return; }
  input.value = '';
  document.getElementById(`post-btn-${id}`).classList.remove('active');
  toast('Komentar terkirim.');
  loadFeed(true);
}

function focusComment(id) {
  document.getElementById(`input-${id}`).focus();
}

function openComments(id) {
  window.location.href = `/post.html?id=${id}`;
}

/* ---------- HAPUS POST (real, hanya pemilik) ---------- */
async function deletePost(id) {
  if (!confirm('Hapus postingan ini secara permanen?')) return;
  const res = await fetch(`/api/posts/${id}`, { method: 'DELETE' });
  if (!res.ok) { toast('Gagal menghapus post.'); return; }
  toast('Post dihapus.');
  loadFeed(true);
}

/* ======================================================
   UPLOAD POST — kirim file gambar ASLI via FormData/multer
   ====================================================== */
const uploadModal = document.getElementById('uploadModal');
const dropzone = document.getElementById('dropzone');
const imageInput = document.getElementById('imageInput');
const imgPreview = document.getElementById('imgPreview');
const dropzoneText = document.getElementById('dropzoneText');
const uploadForm = document.getElementById('uploadForm');

document.getElementById('createBtn').onclick = () => uploadModal.classList.add('open');
document.getElementById('cancelUpload').onclick = () => closeUploadModal();
dropzone.onclick = () => imageInput.click();

imageInput.addEventListener('change', () => {
  const file = imageInput.files[0];
  if (!file) return;
  imgPreview.src = URL.createObjectURL(file);
  imgPreview.style.display = 'block';
  dropzoneText.style.display = 'none';
});

function closeUploadModal() {
  uploadModal.classList.remove('open');
  uploadForm.reset();
  imgPreview.style.display = 'none';
  dropzoneText.style.display = 'block';
}

uploadForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const submitBtn = document.getElementById('submitUpload');
  if (!imageInput.files[0]) { toast('Pilih foto terlebih dahulu.'); return; }
  submitBtn.disabled = true;
  submitBtn.textContent = 'Mengunggah...';

  try {
    const formData = new FormData(uploadForm);
    const res = await fetch('/api/posts', { method: 'POST', body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal mengunggah post.');
    closeUploadModal();
    toast('Postingan berhasil dibagikan.');
    loadFeed(true);
  } catch (err) {
    toast(err.message);
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Bagikan';
  }
});

/* ======================================================
   LOGOUT (real, menghancurkan sesi di server)
   ====================================================== */
document.getElementById('logoutBtn').onclick = async () => {
  await fetch('/api/auth/logout', { method: 'POST' });
  window.location.href = '/login.html';
};

document.getElementById('loadMoreBtn').onclick = () => loadFeed(false);

/* ======================================================
   TOAST
   ====================================================== */
let toastTimer;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 1800);
}

/* ======================================================
   PENCARIAN USER (real, via /api/users/search)
   ====================================================== */
const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');
let searchTimer;

if (searchInput) {
  searchInput.addEventListener('input', () => {
    clearTimeout(searchTimer);
    const q = searchInput.value.trim();
    if (!q) { searchResults.classList.remove('show'); return; }
    searchTimer = setTimeout(async () => {
      const res = await fetch(`/api/users/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      if (data.users.length === 0) {
        searchResults.innerHTML = `<div class="search-row" style="color:var(--text-dim)">Tidak ada hasil.</div>`;
      } else {
        searchResults.innerHTML = data.users.map(u => `
          <div class="search-row" onclick="window.location.href='/profile.html?u=${u.username}'">
            <img class="avatar" src="${fmtAvatar(u.avatar_path)}">
            <div>
              <div style="font-size:13px;font-weight:600;">${escapeHtml(u.username)}</div>
              <div style="font-size:11px;color:var(--text-dim);">${escapeHtml(u.fullname)}</div>
            </div>
          </div>`).join('');
      }
      searchResults.classList.add('show');
    }, 300);
  });
  document.addEventListener('click', (e) => {
    if (!document.getElementById('searchBox').contains(e.target)) {
      searchResults.classList.remove('show');
    }
  });
}

/* ======================================================
   BADGE NOTIFIKASI & PESAN BELUM DIBACA (real, polling)
   ====================================================== */
async function refreshBadges() {
  try {
    const [notifRes, msgRes] = await Promise.all([
      fetch('/api/notifications/unread-count'),
      fetch('/api/messages/unread-count')
    ]);
    const notifData = await notifRes.json();
    const msgData = await msgRes.json();
    document.getElementById('notifBadge').style.display = notifData.count > 0 ? 'block' : 'none';
    document.getElementById('msgBadge').style.display = msgData.count > 0 ? 'block' : 'none';
  } catch (e) { /* diam saja kalau gagal, tidak kritikal */ }
}

/* ======================================================
   INIT
   ====================================================== */
(async function init() {
  currentUser = await checkAuth();
  if (!currentUser) return;
  document.getElementById('navAvatar').src = fmtAvatar(currentUser.avatar_path);
  const profileLink = document.getElementById('profileLink');
  if (profileLink) profileLink.href = `/profile.html?u=${currentUser.username}`;
  loadFeed(true);
  refreshBadges();
  setInterval(refreshBadges, 8000);
})();
