// middleware/auth.js — melindungi route yang butuh login sungguhan

function requireAuth(req, res, next) {
  if (req.session && req.session.userId) {
    return next();
  }
  if (req.headers.accept && req.headers.accept.includes('application/json')) {
    return res.status(401).json({ error: 'Kamu harus login terlebih dahulu.' });
  }
  return res.redirect('/login.html');
}

function attachUser(db) {
  return (req, res, next) => {
    if (req.session && req.session.userId) {
      const user = db.prepare(
        'SELECT id, username, fullname, bio, avatar_path FROM users WHERE id = ?'
      ).get(req.session.userId);
      req.currentUser = user || null;
    } else {
      req.currentUser = null;
    }
    next();
  };
}

module.exports = { requireAuth, attachUser };
