// server.js — server ASLI. Jalankan ini di VPS kamu dengan: npm install && npm start

require('dotenv').config();
const express = require('express');
const path = require('path');
const session = require('express-session');
const FileStore = require('session-file-store')(session);

const db = require('./db'); // inisialisasi skema saat server start
const authRoutes = require('./routes/auth');
const postRoutes = require('./routes/posts');
const userRoutes = require('./routes/users');
const notificationRoutes = require('./routes/notifications');
const messageRoutes = require('./routes/messages');
const { attachUser } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Sesi login disimpan di file (folder /sessions), jadi tetap login walau server di-restart
app.use(session({
  store: new FileStore({ path: path.join(__dirname, 'sessions'), logFn: () => {} }),
  secret: process.env.SESSION_SECRET || 'ganti-secret-ini-di-env',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 24 * 30, // 30 hari
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production' && process.env.FORCE_HTTPS === 'true'
  }
}));

app.use(attachUser(db));

// File statis (HTML/CSS/JS frontend + folder uploads berisi foto asli)
app.use(express.static(path.join(__dirname, 'public')));

// ---------- API ----------
app.use('/api/auth', authRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/users', userRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/messages', messageRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// Tangani error multer (ukuran/format file) dengan rapi
app.use((err, req, res, next) => {
  if (err) {
    return res.status(400).json({ error: err.message || 'Terjadi kesalahan.' });
  }
  next();
});

app.listen(PORT, () => {
  console.log(`Sociogram berjalan di http://localhost:${PORT}`);
});
